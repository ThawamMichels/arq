# 🛒 CAPISHOP Branding Module

Módulo de personalização visual para Odoo com a identidade CAPIBOT.

## 🎨 Cores da Identidade

| Cor | Hex | Uso |
|-----|-----|-----|
| 🟠 Laranja Primária | `#DA5900` | Botões, navbar, destaques |
| 🟠 Laranja Clara | `#EF6800` | Hover, gradientes |
| 🟢 Verde Azulado | `#05B5AD` | Links, badges, sucesso |
| 🔵 Azul Escuro | `#02071A` | Backgrounds, navbar |

## ✨ Recursos

- ✅ Logo customizada (login, menu, favicon)
- ✅ Cores da marca em toda interface
- ✅ Tela de login personalizada
- ✅ Remoção do branding "Odoo"
- ✅ POS (Ponto de Venda) customizado
- ✅ POS Restaurant estilizado

## 📦 Instalação

### Opção 1: Via Volume Docker

1. Extraia o ZIP `capishop_branding.zip`
2. Copie a pasta `capishop_branding` para o volume `odoo-addons` montado em `/mnt/extra-addons`
3. Reinicie o container Odoo
4. Vá em **Configurações > Apps > Atualizar Lista de Apps**
5. Busque "CAPISHOP" e clique em **Instalar**

### Opção 2: Via Terminal do Container

```bash
# Acessar o container
docker exec -it <container_odoo> bash

# Ir para pasta de addons
cd /mnt/extra-addons

# Extrair módulo (se enviado como ZIP)
unzip capishop_branding.zip
```

### No EasyPanel

1. Acesse o terminal do serviço `odoo`
2. Navegue até `/mnt/extra-addons`
3. Crie a pasta do módulo ou faça upload via volume

## 🔧 Estrutura do Módulo

```
capishop_branding/
├── __init__.py
├── __manifest__.py
├── views/
│   └── webclient_templates.xml
└── static/
    ├── description/
    │   ├── banner.png
    │   ├── icon.png
    │   └── index.html
    └── src/
        ├── css/
        │   ├── branding.css
        │   └── login.css
        ├── img/
        │   ├── logo.png
        │   ├── logo_small.png
        │   ├── favicon.png
        │   └── favicon.ico
        └── js/
            └── branding.js
```

## 🖼️ Trocar Logo

Para usar sua própria logo, substitua os arquivos em `static/src/img/`:

- `logo.png` - Logo principal (recomendado: 200x200px ou maior)
- `favicon.png` - Favicon 32x32
- `favicon.ico` - Favicon 16x16

## ⚙️ Personalizar Cores

Edite o arquivo `static/src/css/branding.css` e altere as variáveis:

```css
:root {
    --capishop-primary: #DA5900;    /* Sua cor primária */
    --capishop-secondary: #EF6800;  /* Cor secundária */
    --capishop-accent: #05B5AD;     /* Cor de destaque */
    --capishop-dark: #02071A;       /* Cor escura */
}
```

## 🍕 POS Restaurant

O módulo já inclui estilos para o POS Restaurant:
- Mesas com cores da marca
- Botões estilizados
- Navbar customizada

## 📝 Licença

LGPL-3 - Livre para uso e modificação.

## 👨‍💻 Desenvolvido por

**CAPIBOT** - Automação Inteligente  
🌐 [capibot.com.br](https://capibot.com.br)

---

*Módulo criado com ❤️ para CAPISHOP*
