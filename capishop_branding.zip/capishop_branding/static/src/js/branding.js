/** @odoo-module **/
/*
 * CAPISHOP Branding JavaScript
 * Identidade Visual CAPIBOT
 */

import { patch } from "@web/core/utils/patch";
import { WebClient } from "@web/webclient/webclient";

// Customizar título da página
const originalTitle = document.title;

function updateTitle() {
    if (!document.title.includes('CAPISHOP')) {
        document.title = document.title.replace(/Odoo/gi, 'CAPISHOP');
    }
}

// Observer para mudanças no título
const titleObserver = new MutationObserver(function(mutations) {
    updateTitle();
});

// Observar mudanças no título
const titleElement = document.querySelector('title');
if (titleElement) {
    titleObserver.observe(titleElement, { childList: true });
}

// Atualizar título inicial
document.addEventListener('DOMContentLoaded', function() {
    updateTitle();
    
    // Trocar textos "Odoo" por "CAPISHOP"
    const replaceOdooText = () => {
        const walker = document.createTreeWalker(
            document.body,
            NodeFilter.SHOW_TEXT,
            null,
            false
        );
        
        let node;
        while (node = walker.nextNode()) {
            if (node.nodeValue && node.nodeValue.includes('Odoo')) {
                // Não substituir em elementos específicos (scripts, etc)
                if (node.parentNode && 
                    !['SCRIPT', 'STYLE', 'NOSCRIPT'].includes(node.parentNode.tagName)) {
                    node.nodeValue = node.nodeValue.replace(/Odoo/g, 'CAPISHOP');
                }
            }
        }
    };
    
    // Executar substituição após carregamento
    setTimeout(replaceOdooText, 1000);
    setTimeout(replaceOdooText, 3000);
});

// Adicionar classe customizada ao body
document.body.classList.add('capishop-branding');

// Console log para confirmar carregamento
console.log('%c🛒 CAPISHOP Branding Loaded!', 'color: #DA5900; font-size: 16px; font-weight: bold;');
console.log('%c   Powered by CAPIBOT', 'color: #05B5AD; font-size: 12px;');
