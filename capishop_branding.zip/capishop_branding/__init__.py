# -*- coding: utf-8 -*-
# CAPISHOP Branding Module
# Powered by CAPIBOT
