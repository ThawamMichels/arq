# -*- coding: utf-8 -*-
{
    'name': 'CAPISHOP Branding',
    'version': '17.0.1.0.0',
    'category': 'Tools',
    'summary': 'Customização visual CAPISHOP - Identidade CAPIBOT',
    'description': """
        Módulo de Branding CAPISHOP
        ===========================
        
        Este módulo personaliza a interface do Odoo com a identidade visual CAPISHOP/CAPIBOT:
        
        * Logo customizada na tela de login
        * Logo no menu principal
        * Favicon personalizado
        * Cores da marca (Laranja #DA5900)
        * Remoção do "Powered by Odoo"
        * Título da página customizado
        
        Desenvolvido por CAPIBOT - Automação Inteligente
    """,
    'author': 'CAPIBOT',
    'website': 'https://capibot.com.br',
    'license': 'LGPL-3',
    'depends': ['base', 'web'],
    'data': [
        'views/webclient_templates.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'capishop_branding/static/src/css/branding.css',
            'capishop_branding/static/src/js/branding.js',
        ],
        'web.assets_frontend': [
            'capishop_branding/static/src/css/branding.css',
        ],
        'web.login_assets': [
            'capishop_branding/static/src/css/login.css',
        ],
    },
    'images': ['static/description/banner.png'],
    'installable': True,
    'auto_install': False,
    'application': False,
}
